# Context7 參考文檔索引

Complete reference documentation for Context7 MCP server.

## 📚 參考文檔列表

### 1. 安裝設定指南 (setup.md)
完整的安裝和配置指南：
- 📋 系統需求和先決條件
- 🖥️ Cursor 設置（遠端和本地）
- 🤖 Claude Code 安裝
- 🌐 Opencode 配置
- 🔐 OAuth 設置
- 🛠️ 進階配置（環境變數、代理、超時）
- ✅ 驗證和測試
- 🐛 故障排除
- 🔄 更新管理

### 2. API 參考 (api.md)
詳細的 API 文檔：
- 🔧 `resolve-library-id` 工具
  - 參數說明
  - 返回值結構
  - 使用範例
  - 錯誤處理
- 🔧 `query-docs` 工具
  - 參數說明
  - 文檔返回格式
  - 代碼範例結構
  - 錯誤代碼
- 📊 響應結構
- 🔍 Library ID 格式
- 🎯 常見模式
- ⚡ 性能優化技巧
- 📈 速率限制
- 🔒 認證方法

### 3. 使用範例 (examples.md)
實際使用案例：
- 🚀 快速入門範例
  - 簡單查詢
  - 版本特定查詢
  - 庫特定查詢
- 🌐 Web 開發範例
  - Next.js（Server Actions、Middleware）
  - React（Hooks、Suspense）
  - Tailwind CSS（響應式設計、深色模式）
- 🗄️ 數據庫範例
  - Supabase（認證、實時訂閱）
  - Prisma（Schema 設計）
- 🎨 UI 框架範例
  - Shadcn UI（表單驗證）
- 🔧 後端範例
  - Express.js（REST API、中間件）
- 🧪 測試範例
  - Vitest（單元測試）
- 📱 移動開發範例
  - React Native（Expo Router）
- 🎓 進階範例
  - 多庫集成
  - 自動化規則

### 4. 客戶端配置 (clients.md)
所有支援客戶端的配置：
- 🖥️ Cursor（遠端、本地、項目特定）
- 🤖 Claude Code
- 🌐 Opencode
- 🪟 Windsurf
- 🦆 Goose
- 🎯 Aide
- 📋 VS Code + Continue
- 🔧 自定義 MCP 客戶端
- 🔐 OAuth 配置
- 🌍 進階配置（代理、超時、自定義標頭）
- 📊 配置比較
- ✅ 驗證方法
- 🐛 常見問題
- 📝 配置模板

## 🎯 如何使用這些文檔

### 初次使用者
1. 閱讀主 **SKILL.md** 了解 Context7 基本概念
2. 查看 **setup.md** 進行安裝配置
3. 參考 **examples.md** 開始使用
4. 查閱 **clients.md** 獲取客戶端特定設置

### 查詢特定資訊
- **安裝問題** → setup.md
- **API 調用** → api.md
- **代碼範例** → examples.md
- **客戶端設置** → clients.md

### 按場景搜尋
- **Web 開發** → examples.md（Next.js、React、Tailwind）
- **數據庫** → examples.md（Supabase、Prisma）
- **測試** → examples.md（Vitest）
- **移動開發** → examples.md（React Native）
- **故障排除** → setup.md、clients.md

## 📖 文檔特色

### 詳細程度
- ⭐⭐⭐⭐⭐ 超詳細：包含完整配置範例
- 代碼範例：真實可用的代碼
- 實用建議：最佳實踐和技巧

### 資訊更新
- 所有資訊更新至 2026 年 1 月
- 包含最新 API 和功能
- 支援最新版本的客戶端

### 語言
- 完整英文文檔
- 清晰的代碼註釋
- 易於理解的範例

## 🔗 官方資源

本 skill 參考以下官方來源：
- **Context7 官網**: https://context7.com
- **GitHub Repository**: https://github.com/upstash/context7
- **NPM Package**: [@upstash/context7-mcp](https://www.npmjs.com/package/@upstash/context7-mcp)
- **Upstash Blog**: https://upstash.com/blog/context7-mcp
- **API Dashboard**: https://context7.com/dashboard

## 💡 使用建議

### 行前準備
1. 閱讀完整 SKILL.md 獲得概覽
2. 根據使用的客戶端選擇配置方法
3. 準備 API Key（推薦）：
   - 訪問 context7.com/dashboard
   - 免費註冊
   - 複製 API Key

### 使用中
1. 使用離線版本（下載後可離線查閱）
2. 查詢當天需要的文檔
3. 參考範例快速上手
4. 遇到問題查詢對應故障排除章節

### 進階使用
1. 設置自動化規則
2. 探索多庫集成
3. 優化性能配置
4. 貢獻社區範例

---

## 📊 文檔統計

- **總頁數**: 4 個主要參考文檔 + 1 個索引
- **代碼範例**: 50+ 個實用範例
- **支援客戶端**: 30+ 個
- **涵蓋主題**:
  - Web 開發（Next.js、React、Tailwind）
  - 數據庫（Supabase、Prisma）
  - 後端（Express.js）
  - 測試（Vitest）
  - 移動（React Native）
- **配置模板**: 15+ 個

## 🚀 快速導航

### 我想...

**安裝 Context7**
→ 查看 **setup.md**

**了解 API**
→ 查看 **api.md**

**查看代碼範例**
→ 查看 **examples.md**

**配置特定客戶端**
→ 查看 **clients.md**

**解決問題**
→ 查看 **setup.md** 或 **clients.md** 的故障排除章節

**學習最佳實踐**
→ 查看 **examples.md** 的進階範例

---

**最後更新**: 2026 年 1 月
**維護者**: Upstash Team
**License**: MIT
