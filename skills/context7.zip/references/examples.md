# Context7 Usage Examples

Practical examples showing how to use Context7 in real-world scenarios.

## 🚀 Quick Start Examples

### Example 1: Simple Query

**Prompt:**
```
Create a Next.js API route. use context7
```

**What happens:**
1. Context7 resolves "Next.js" → `/vercel/next.js`
2. Fetches latest Next.js API routes documentation
3. LLM receives up-to-date examples
4. You get working code with correct syntax

**Result:**
```typescript
// app/api/hello/route.ts
import { NextResponse } from 'next/server';

export async function GET() {
  return NextResponse.json({ message: 'Hello World' });
}
```

---

### Example 2: Version-Specific

**Prompt:**
```
How to use React 18 concurrent features? use context7
```

**What happens:**
1. Detects "React 18" in query
2. Fetches React 18.x documentation
3. Returns concurrent-specific features

**Result:**
Documentation for:
- `useTransition`
- `useDeferredValue`
- Suspense boundaries
- Concurrent rendering

---

### Example 3: Library-Specific

**Prompt:**
```
use library /supabase/supabase
How to implement real-time subscriptions?
```

**What happens:**
1. Uses explicit library ID `/supabase/supabase`
2. Fetches Supabase real-time docs
3. Returns code examples

**Result:**
```typescript
const subscription = supabase
  .channel('todos')
  .on('postgres_changes',
    { event: '*', schema: 'public', table: 'todos' },
    (payload) => console.log(payload)
  )
  .subscribe();
```

---

## 🌐 Web Development Examples

### Next.js Examples

#### Server Actions

**Prompt:**
```
Create Next.js 15 server action for form submission. use context7
```

**Result:**
```typescript
// app/actions.ts
'use server'

import { revalidatePath } from 'next/cache';

export async function submitForm(formData: FormData) {
  const name = formData.get('name');

  // Process form data
  await saveToDatabase(name);

  // Revalidate the page
  revalidatePath('/');

  return { success: true };
}
```

#### Middleware

**Prompt:**
```
use library /vercel/next.js/14
Create middleware to check authentication
```

**Result:**
```typescript
// middleware.ts
import { NextResponse } from 'next/server';
import type { NextRequest } from 'next/server';

export function middleware(request: NextRequest) {
  const token = request.cookies.get('auth-token');

  if (!token && request.nextUrl.pathname.startsWith('/dashboard')) {
    return NextResponse.redirect(new URL('/login', request.url));
  }

  return NextResponse.next();
}

export const config = {
  matcher: '/dashboard/:path*'
};
```

---

### React Examples

#### Custom Hook

**Prompt:**
```
Create React 18 custom hook for data fetching. use context7
```

**Result:**
```typescript
import { useState, useEffect } from 'react';

function useFetch<T>(url: string) {
  const [data, setData] = useState<T | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<Error | null>(null);

  useEffect(() => {
    fetch(url)
      .then(res => res.json())
      .then(setData)
      .catch(setError)
      .finally(() => setLoading(false));
  }, [url]);

  return { data, loading, error };
}
```

#### Suspense Boundary

**Prompt:**
```
use library /facebook/react/18
Create component with Suspense for data loading
```

**Result:**
```tsx
import { Suspense } from 'react';

function App() {
  return (
    <Suspense fallback={<Loading />}>
      <UserProfile />
    </Suspense>
  );
}

function Loading() {
  return <div>Loading...</div>;
}
```

---

### Tailwind CSS Examples

#### Responsive Navbar

**Prompt:**
```
Create Tailwind CSS responsive navbar with dark mode. use context7
```

**Result:**
```tsx
<nav className="bg-white dark:bg-gray-800 shadow-lg">
  <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
    <div className="flex justify-between h-16">
      <div className="flex items-center">
        <h1 className="text-xl font-bold text-gray-900 dark:text-white">
          Logo
        </h1>
      </div>

      {/* Desktop menu */}
      <div className="hidden md:flex items-center space-x-4">
        <a href="#" className="text-gray-700 dark:text-gray-300 hover:text-gray-900 dark:hover:text-white">
          Home
        </a>
        <a href="#" className="text-gray-700 dark:text-gray-300 hover:text-gray-900 dark:hover:text-white">
          About
        </a>
      </div>

      {/* Mobile menu button */}
      <div className="md:hidden flex items-center">
        <button className="text-gray-700 dark:text-gray-300">
          <svg className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
          </svg>
        </button>
      </div>
    </div>
  </div>
</nav>
```

---

## 🗄️ Database Examples

### Supabase Examples

#### Authentication

**Prompt:**
```
use library /supabase/supabase
Implement email/password authentication with error handling
```

**Result:**
```typescript
async function signUp(email: string, password: string) {
  const { data, error } = await supabase.auth.signUp({
    email,
    password
  });

  if (error) {
    console.error('Sign up error:', error.message);
    return { success: false, error: error.message };
  }

  return { success: true, user: data.user };
}

async function signIn(email: string, password: string) {
  const { data, error } = await supabase.auth.signInWithPassword({
    email,
    password
  });

  if (error) {
    console.error('Sign in error:', error.message);
    return { success: false, error: error.message };
  }

  return { success: true, session: data.session };
}
```

#### Real-time Subscriptions

**Prompt:**
```
use library /supabase/supabase
Subscribe to database changes for a chat app
```

**Result:**
```typescript
import { useEffect, useState } from 'react';

function ChatRoom({ roomId }: { roomId: string }) {
  const [messages, setMessages] = useState([]);

  useEffect(() => {
    // Fetch initial messages
    const fetchMessages = async () => {
      const { data } = await supabase
        .from('messages')
        .select('*')
        .eq('room_id', roomId)
        .order('created_at', { ascending: true });

      setMessages(data || []);
    };

    fetchMessages();

    // Subscribe to new messages
    const subscription = supabase
      .channel(`room:${roomId}`)
      .on(
        'postgres_changes',
        {
          event: 'INSERT',
          schema: 'public',
          table: 'messages',
          filter: `room_id=eq.${roomId}`
        },
        (payload) => {
          setMessages(prev => [...prev, payload.new]);
        }
      )
      .subscribe();

    return () => {
      subscription.unsubscribe();
    };
  }, [roomId]);

  return (
    <div>
      {messages.map(msg => (
        <div key={msg.id}>{msg.content}</div>
      ))}
    </div>
  );
}
```

---

### Prisma Examples

**Prompt:**
```
use library /prisma/prisma
Create Prisma schema for blog with posts and comments
```

**Result:**
```prisma
// schema.prisma
datasource db {
  provider = "postgresql"
  url      = env("DATABASE_URL")
}

generator client {
  provider = "prisma-client-js"
}

model User {
  id        Int      @id @default(autoincrement())
  email     String   @unique
  name      String?
  posts     Post[]
  comments  Comment[]
  createdAt DateTime @default(now())
}

model Post {
  id        Int      @id @default(autoincrement())
  title     String
  content   String
  published Boolean  @default(false)
  author    User     @relation(fields: [authorId], references: [id])
  authorId  Int
  comments  Comment[]
  createdAt DateTime @default(now())
  updatedAt DateTime @updatedAt
}

model Comment {
  id        Int      @id @default(autoincrement())
  content   String
  post      Post     @relation(fields: [postId], references: [id])
  postId    Int
  author    User     @relation(fields: [authorId], references: [id])
  authorId  Int
  createdAt DateTime @default(now())
}
```

---

## 🎨 UI Framework Examples

### Shadcn UI

**Prompt:**
```
use library /shadcn/ui
Create a form with validation using react-hook-form
```

**Result:**
```tsx
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";
import { Button } from "@/components/ui/button";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";

const formSchema = z.object({
  email: z.string().email(),
  password: z.string().min(8),
});

export function LoginForm() {
  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      email: "",
      password: "",
    },
  });

  function onSubmit(values: z.infer<typeof formSchema>) {
    console.log(values);
  }

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
        <FormField
          control={form.control}
          name="email"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Email</FormLabel>
              <FormControl>
                <Input placeholder="email@example.com" {...field} />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />
        <Button type="submit">Submit</Button>
      </form>
    </Form>
  );
}
```

---

## 🔧 Backend Examples

### Express.js

**Prompt:**
```
use library /expressjs/express
Create REST API with middleware and error handling
```

**Result:**
```typescript
import express from 'express';

const app = express();

// Middleware
app.use(express.json());

// Logger middleware
app.use((req, res, next) => {
  console.log(`${req.method} ${req.path}`);
  next();
});

// Routes
app.get('/api/users', async (req, res) => {
  const users = await getUsers();
  res.json(users);
});

app.post('/api/users', async (req, res) => {
  const user = await createUser(req.body);
  res.status(201).json(user);
});

// Error handling
app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(500).json({ error: 'Something went wrong!' });
});

app.listen(3000, () => {
  console.log('Server running on port 3000');
});
```

---

## 🧪 Testing Examples

### Vitest

**Prompt:**
```
use library /vitest-dev/vitest
Write unit tests for React component
```

**Result:**
```typescript
import { describe, it, expect } from 'vitest';
import { render, screen } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { Counter } from './Counter';

describe('Counter', () => {
  it('renders initial count', () => {
    render(<Counter initialCount={0} />);
    expect(screen.getByText('Count: 0')).toBeInTheDocument();
  });

  it('increments count on button click', async () => {
    const user = userEvent.setup();
    render(<Counter initialCount={0} />);

    const button = screen.getByRole('button', { name: /increment/i });
    await user.click(button);

    expect(screen.getByText('Count: 1')).toBeInTheDocument();
  });
});
```

---

## 📱 Mobile Examples

### React Native

**Prompt:**
```
use library /facebook/react-native
Create login screen with Expo Router
```

**Result:**
```tsx
import { View, Text, TextInput, Pressable, StyleSheet } from 'react-native';
import { useState } from 'react';
import { useRouter } from 'expo-router';

export default function LoginScreen() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const router = useRouter();

  const handleLogin = async () => {
    // Authentication logic
    router.push('/home');
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Login</Text>

      <TextInput
        style={styles.input}
        placeholder="Email"
        value={email}
        onChangeText={setEmail}
        autoCapitalize="none"
        keyboardType="email-address"
      />

      <TextInput
        style={styles.input}
        placeholder="Password"
        value={password}
        onChangeText={setPassword}
        secureTextEntry
      />

      <Pressable style={styles.button} onPress={handleLogin}>
        <Text style={styles.buttonText}>Login</Text>
      </Pressable>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
    justifyContent: 'center',
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 20,
  },
  input: {
    borderWidth: 1,
    borderColor: '#ddd',
    padding: 10,
    marginBottom: 10,
    borderRadius: 5,
  },
  button: {
    backgroundColor: '#007AFF',
    padding: 15,
    borderRadius: 5,
    alignItems: 'center',
  },
  buttonText: {
    color: 'white',
    fontWeight: 'bold',
  },
});
```

---

## 🎓 Advanced Examples

### Multi-Library Integration

**Prompt:**
```
Create full-stack Next.js app with Supabase auth and Tailwind UI. use context7
```

**Result:**
Context7 automatically fetches docs for:
- Next.js (latest)
- Supabase (auth features)
- Tailwind CSS (styling)

Combined into comprehensive examples.

---

### Automation Rule Example

**Cursor Settings → Rules:**

```
For all TypeScript/JavaScript code tasks:
1. Use context7 to fetch latest documentation
2. Prioritize version-specific examples
3. Include error handling
4. Follow library best practices
```

**Effect:**
Every code request automatically uses Context7 without manual prompting.

---

**Next Steps**: See `clients.md` for client-specific configurations
