# Context7 Client Configurations

Complete configuration guide for all supported MCP clients.

## 🖥️ Cursor

### Remote Server (Recommended)

**Location**: `~/.cursor/mcp.json`

```json
{
  "mcpServers": {
    "context7": {
      "url": "https://mcp.context7.com/mcp",
      "headers": {
        "CONTEXT7_API_KEY": "ctx7_your_api_key_here"
      }
    }
  }
}
```

**Pros**:
- ✅ Fast and reliable
- ✅ Managed infrastructure
- ✅ Auto-updates

**Cons**:
- ❌ Requires internet
- ❌ Data sent to remote server

### Local Server

```json
{
  "mcpServers": {
    "context7": {
      "command": "npx",
      "args": [
        "-y",
        "@upstash/context7-mcp",
        "--api-key",
        "ctx7_your_api_key_here"
      ]
    }
  }
}
```

**Pros**:
- ✅ More privacy
- ✅ Works offline (cached)

**Cons**:
- ❌ Uses local resources
- ❌ Slower first run

### Project-Specific

**Location**: `.cursor/mcp.json` (in project root)

```json
{
  "mcpServers": {
    "context7": {
      "url": "https://mcp.context7.com/mcp",
      "headers": {
        "CONTEXT7_API_KEY": "ctx7_project_specific_key"
      }
    }
  }
}
```

**Use case**: Different API keys per project

---

## 🤖 Claude Code

### Installation

```bash
claude mcp add context7 -- npx -y @upstash/context7-mcp --api-key YOUR_KEY
```

### Manual Config

**Location**: `~/.claude/mcp.json`

```json
{
  "mcpServers": {
    "context7": {
      "command": "npx",
      "args": [
        "-y",
        "@upstash/context7-mcp",
        "--api-key",
        "ctx7_your_api_key_here"
      ]
    }
  }
}
```

### Environment Variables

```bash
# Set globally
export CONTEXT7_API_KEY=ctx7_your_key_here

# Add to ~/.bashrc or ~/.zshrc
echo 'export CONTEXT7_API_KEY=ctx7_your_key_here' >> ~/.bashrc
```

**Config with env var**:
```json
{
  "mcpServers": {
    "context7": {
      "command": "npx",
      "args": ["-y", "@upstash/context7-mcp"],
      "env": {
        "CONTEXT7_API_KEY": "${CONTEXT7_API_KEY}"
      }
    }
  }
}
```

---

## 🌐 Opencode

### Configuration

**Location**: Project-specific config

```json
{
  "mcp": {
    "servers": {
      "context7": {
        "command": "npx",
        "args": [
          "-y",
          "@upstash/context7-mcp",
          "--api-key",
          "ctx7_your_api_key_here"
        ]
      }
    }
  }
}
```

---

## 🪟 Windsurf

### Configuration

**Location**: `~/.windsurf/mcp.json`

```json
{
  "mcpServers": {
    "context7": {
      "url": "https://mcp.context7.com/mcp",
      "headers": {
        "CONTEXT7_API_KEY": "ctx7_your_api_key_here"
      }
    }
  }
}
```

---

## 🦆 Goose

### Configuration

**Location**: `~/.goose/mcp.json`

```json
{
  "mcpServers": {
    "context7": {
      "command": "npx",
      "args": [
        "-y",
        "@upstash/context7-mcp",
        "--api-key",
        "ctx7_your_api_key_here"
      ]
    }
  }
}
```

---

## 🎯 Aide

### Configuration

**Location**: `.aide/mcp.json`

```json
{
  "mcp": {
    "servers": {
      "context7": {
        "url": "https://mcp.context7.com/mcp",
        "apiKey": "ctx7_your_api_key_here"
      }
    }
  }
}
```

---

## 📋 VS Code + Continue

### Configuration

**Location**: `.continue/config.json`

```json
{
  "mcpServers": [
    {
      "name": "context7",
      "command": "npx",
      "args": [
        "-y",
        "@upstash/context7-mcp",
        "--api-key",
        "ctx7_your_api_key_here"
      ]
    }
  ]
}
```

---

## 🔧 Custom MCP Client

### Generic Configuration

For any MCP-compatible client:

```json
{
  "mcpServers": {
    "context7": {
      "url": "https://mcp.context7.com/mcp",
      "headers": {
        "CONTEXT7_API_KEY": "ctx7_your_api_key_here"
      }
    }
  }
}
```

Or local:

```json
{
  "mcpServers": {
    "context7": {
      "command": "npx",
      "args": ["-y", "@upstash/context7-mcp", "--api-key", "YOUR_KEY"]
    }
  }
}
```

---

## 🔐 OAuth Configuration

### Cursor OAuth

```json
{
  "mcpServers": {
    "context7": {
      "url": "https://mcp.context7.com/mcp/oauth",
      "oauth": {
        "clientId": "your-client-id",
        "scopes": ["read:docs"],
        "authorizationEndpoint": "https://context7.com/oauth/authorize",
        "tokenEndpoint": "https://context7.com/oauth/token"
      }
    }
  }
}
```

### Flow

1. Client initiates OAuth flow
2. User redirected to Context7 login
3. User authorizes application
4. Token returned to client
5. Token used for subsequent requests

---

## 🌍 Advanced Configurations

### Proxy Support

```json
{
  "mcpServers": {
    "context7": {
      "url": "https://mcp.context7.com/mcp",
      "proxy": "http://proxy.company.com:8080",
      "headers": {
        "CONTEXT7_API_KEY": "ctx7_your_api_key_here"
      }
    }
  }
}
```

### Custom Timeout

```json
{
  "mcpServers": {
    "context7": {
      "url": "https://mcp.context7.com/mcp",
      "timeout": 30000,
      "headers": {
        "CONTEXT7_API_KEY": "ctx7_your_api_key_here"
      }
    }
  }
}
```

### Custom Headers

```json
{
  "mcpServers": {
    "context7": {
      "url": "https://mcp.context7.com/mcp",
      "headers": {
        "CONTEXT7_API_KEY": "ctx7_your_api_key_here",
        "X-Custom-Header": "custom-value",
        "User-Agent": "MyApp/1.0"
      }
    }
  }
}
```

---

## 📊 Configuration Comparison

| Feature | Remote | Local | OAuth |
|---------|--------|-------|-------|
| Speed | Fast | Slower first run | Fast |
| Privacy | Medium | High | Medium |
| Setup | Easy | Easy | Medium |
| Offline | No | Yes (cached) | No |
| Updates | Auto | Manual | Auto |

---

## ✅ Verification

### Test Commands

**Cursor**:
```
Cmd/Ctrl + Shift + P → "MCP: List Servers"
```

**Claude Code**:
```bash
claude mcp list
claude mcp test context7
```

**Manual**:
```bash
npx -y @upstash/context7-mcp --api-key YOUR_KEY
# Should start without errors
```

### Check Logs

**Cursor**:
- Help → Toggle Developer Tools
- Check Console for MCP messages

**Claude Code**:
```bash
claude mcp logs context7
```

### Verify Tools

Should see:
- ✅ `resolve-library-id`
- ✅ `query-docs`

---

## 🐛 Common Issues

### "Server not found"

**Solution**:
1. Check JSON syntax (use JSON validator)
2. Restart client
3. Check config file location
4. Verify MCP support in client

### "Authentication failed"

**Solution**:
1. Verify API key format: `ctx7_...`
2. Check key is not expired
3. Test key: `curl -H "CONTEXT7_API_KEY: YOUR_KEY" https://mcp.context7.com/health`
4. Regenerate key if needed

### "Connection timeout"

**Solution**:
1. Check internet connection
2. Test endpoint: `curl https://mcp.context7.com/health`
3. Try local server instead
4. Increase timeout in config

---

## 📝 Configuration Templates

### Minimal (Testing)

```json
{
  "mcpServers": {
    "context7": {
      "url": "https://mcp.context7.com/mcp"
    }
  }
}
```

### Production (Recommended)

```json
{
  "mcpServers": {
    "context7": {
      "url": "https://mcp.context7.com/mcp",
      "timeout": 30000,
      "headers": {
        "CONTEXT7_API_KEY": "ctx7_production_key_here"
      }
    }
  }
}
```

### Enterprise (Full Features)

```json
{
  "mcpServers": {
    "context7": {
      "url": "https://mcp.context7.com/mcp",
      "timeout": 30000,
      "proxy": "http://proxy.company.com:8080",
      "headers": {
        "CONTEXT7_API_KEY": "ctx7_enterprise_key_here",
        "X-Organization-Id": "org-12345"
      }
    }
  }
}
```

---

**Next Steps**: See `examples.md` for usage examples with your client
