# Context7 Setup Guide

Complete installation and configuration guide for Context7 MCP server across different platforms.

## 📋 Prerequisites

### System Requirements
- **Node.js**: 16.0 or higher (for local server)
- **NPM/NPX**: Latest version
- **MCP-compatible client**: Cursor, Claude Code, Opencode, etc.

### Get API Key (Optional but Recommended)

1. Visit https://context7.com/dashboard
2. Sign up with email or GitHub
3. Navigate to API Keys section
4. Click "Create New Key"
5. Copy and save securely

**Benefits:**
- 🚀 10x higher rate limits
- 📊 Usage analytics
- 🔒 Authenticated access
- 💰 Free tier: 1,000 requests/month

---

## 🖥️ Cursor Setup

### Method 1: Remote Server (Recommended)

**Pros**: Fast, managed, no local resources
**Cons**: Requires internet connection

**Steps:**

1. **Create/Edit MCP config**:
   ```bash
   # macOS/Linux
   mkdir -p ~/.cursor
   nano ~/.cursor/mcp.json

   # Windows
   mkdir %USERPROFILE%\.cursor
   notepad %USERPROFILE%\.cursor\mcp.json
   ```

2. **Add configuration**:
   ```json
   {
     "mcpServers": {
       "context7": {
         "url": "https://mcp.context7.com/mcp",
         "headers": {
           "CONTEXT7_API_KEY": "ctx7_your_api_key_here"
         }
       }
     }
   }
   ```

3. **Restart Cursor**:
   - Close Cursor completely
   - Reopen Cursor
   - Or: `Cmd/Ctrl + Shift + P` → "MCP: Restart Servers"

4. **Verify**:
   - Open a new chat
   - Type: "test context7 connection"
   - Should show available tools

### Method 2: Local Server

**Pros**: More privacy, works offline (cached)
**Cons**: Uses local resources

**Steps:**

1. **Edit `~/.cursor/mcp.json`**:
   ```json
   {
     "mcpServers": {
       "context7": {
         "command": "npx",
         "args": [
           "-y",
           "@upstash/context7-mcp",
           "--api-key",
           "ctx7_your_api_key_here"
         ]
       }
     }
   }
   ```

2. **First run** (downloads package):
   ```bash
   npx -y @upstash/context7-mcp --api-key YOUR_KEY
   ```

3. **Restart Cursor**

### Project-Specific Setup

For per-project configuration:

1. **Create project config**:
   ```bash
   mkdir .cursor
   nano .cursor/mcp.json
   ```

2. **Add same configuration** as above

3. **Priority**: Project config overrides global config

---

## 🤖 Claude Code Setup

### Installation

```bash
# Install Context7 MCP server
claude mcp add context7 -- npx -y @upstash/context7-mcp --api-key YOUR_API_KEY

# Verify installation
claude mcp list

# Test connection
claude mcp test context7
```

### Configuration File

Claude Code stores config in `~/.claude/mcp.json`:

```json
{
  "mcpServers": {
    "context7": {
      "command": "npx",
      "args": [
        "-y",
        "@upstash/context7-mcp",
        "--api-key",
        "ctx7_your_api_key_here"
      ]
    }
  }
}
```

### Restart Server

```bash
claude mcp restart context7
```

---

## 🌐 Opencode Setup

1. **Install via NPX**:
   ```bash
   npx -y @upstash/context7-mcp --api-key YOUR_API_KEY
   ```

2. **Add to Opencode config**:
   ```json
   {
     "mcp": {
       "servers": {
         "context7": {
           "command": "npx",
           "args": ["-y", "@upstash/context7-mcp", "--api-key", "YOUR_KEY"]
         }
       }
     }
   }
   ```

---

## 🔐 OAuth Setup

For clients supporting MCP OAuth specification:

### Cursor OAuth Config

```json
{
  "mcpServers": {
    "context7": {
      "url": "https://mcp.context7.com/mcp/oauth",
      "oauth": {
        "clientId": "your-client-id",
        "scopes": ["read:docs"]
      }
    }
  }
}
```

### OAuth Flow

1. Client initiates OAuth
2. Redirect to Context7 login
3. User authorizes
4. Token stored securely
5. Future requests authenticated

**Benefits:**
- No manual API key management
- Token rotation
- Revocable access
- Granular permissions

---

## 🛠️ Advanced Configuration

### Environment Variables

```bash
# Set globally
export CONTEXT7_API_KEY=ctx7_your_key_here

# Use in config
{
  "mcpServers": {
    "context7": {
      "command": "npx",
      "args": ["-y", "@upstash/context7-mcp"],
      "env": {
        "CONTEXT7_API_KEY": "${CONTEXT7_API_KEY}"
      }
    }
  }
}
```

### Custom Timeout

```json
{
  "mcpServers": {
    "context7": {
      "url": "https://mcp.context7.com/mcp",
      "timeout": 30000,
      "headers": {
        "CONTEXT7_API_KEY": "YOUR_KEY"
      }
    }
  }
}
```

### Proxy Configuration

```json
{
  "mcpServers": {
    "context7": {
      "url": "https://mcp.context7.com/mcp",
      "proxy": "http://proxy.company.com:8080",
      "headers": {
        "CONTEXT7_API_KEY": "YOUR_KEY"
      }
    }
  }
}
```

---

## ✅ Verification

### Test Connection

**Cursor:**
1. Open new chat
2. Type: "use context7 to show Next.js version"
3. Should fetch and display docs

**Claude Code:**
```bash
claude mcp test context7
```

**Manual Test:**
```bash
npx -y @upstash/context7-mcp --api-key YOUR_KEY
# Should start server without errors
```

### Check Logs

**Cursor:**
- `Help` → `Toggle Developer Tools`
- Check Console for MCP messages

**Claude Code:**
```bash
claude mcp logs context7
```

### Verify Tools Available

Should show:
- ✅ `resolve-library-id`
- ✅ `query-docs`

---

## 🐛 Troubleshooting

### "Context7 not found"

**Solution:**
1. Check config file syntax (valid JSON)
2. Restart client
3. Check API key is valid
4. Verify internet connection

### "Rate limit exceeded"

**Solution:**
1. Get API key from context7.com/dashboard
2. Switch to local server
3. Wait for rate limit reset (1 hour)

### Local server won't start

**Solution:**
1. Update Node.js: `node --version` (need 16+)
2. Clear NPX cache: `npx clear-cache`
3. Reinstall: `npx -y @upstash/context7-mcp`

### Connection timeout

**Solution:**
1. Check firewall settings
2. Test network: `curl https://mcp.context7.com/health`
3. Try local server instead
4. Increase timeout in config

---

## 🔄 Updates

### Auto-update (NPX)

NPX automatically downloads latest version:
```bash
npx -y @upstash/context7-mcp
# -y flag: auto-confirm updates
```

### Check Current Version

```bash
npm view @upstash/context7-mcp version
```

### Force Update

```bash
npx clear-cache
npx -y @upstash/context7-mcp --api-key YOUR_KEY
```

---

## 📝 Configuration Templates

### Minimal (No API Key)

```json
{
  "mcpServers": {
    "context7": {
      "url": "https://mcp.context7.com/mcp"
    }
  }
}
```

### Production (With API Key + Timeout)

```json
{
  "mcpServers": {
    "context7": {
      "url": "https://mcp.context7.com/mcp",
      "timeout": 30000,
      "headers": {
        "CONTEXT7_API_KEY": "ctx7_prod_key_here"
      }
    }
  }
}
```

### Development (Local Server)

```json
{
  "mcpServers": {
    "context7": {
      "command": "npx",
      "args": ["-y", "@upstash/context7-mcp", "--api-key", "ctx7_dev_key"],
      "env": {
        "NODE_ENV": "development"
      }
    }
  }
}
```

---

**Next Steps**: See `examples.md` for usage examples
