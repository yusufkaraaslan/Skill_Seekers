# Context7 API Reference

Complete API documentation for Context7 MCP server tools and functions.

## 🔧 Available Tools

Context7 provides 2 main MCP tools for interacting with the documentation database:

---

## 1. `resolve-library-id`

Resolves a package/product name to a Context7-compatible library ID.

### Purpose

Convert human-readable library names (e.g., "supabase", "next.js") into standardized Context7 library IDs (e.g., `/supabase/supabase`, `/vercel/next.js`).

### When to Use

**MUST call before `query-docs`** UNLESS the user explicitly provides a library ID in the format:
- `/org/project`
- `/org/project/version`

### Parameters

| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| `query` | string | Yes | The user's question or request |
| `libraryName` | string | Yes | Name of the library to resolve |

### Returns

```json
{
  "libraries": [
    {
      "id": "/supabase/supabase",
      "name": "Supabase",
      "description": "Open source Firebase alternative",
      "version": "latest",
      "stars": 50000
    }
  ]
}
```

### Examples

#### Example 1: Simple Library Name

**Input:**
```json
{
  "query": "How to authenticate users?",
  "libraryName": "supabase"
}
```

**Output:**
```json
{
  "libraries": [
    {
      "id": "/supabase/supabase",
      "name": "Supabase",
      "version": "latest"
    }
  ]
}
```

#### Example 2: Ambiguous Name

**Input:**
```json
{
  "query": "Create a React component",
  "libraryName": "react"
}
```

**Output:**
```json
{
  "libraries": [
    {
      "id": "/facebook/react",
      "name": "React",
      "version": "18.2.0"
    },
    {
      "id": "/facebook/react",
      "name": "React",
      "version": "17.0.2"
    }
  ]
}
```

#### Example 3: Version-Specific

**Input:**
```json
{
  "query": "Next.js 14 middleware",
  "libraryName": "next.js"
}
```

**Output:**
```json
{
  "libraries": [
    {
      "id": "/vercel/next.js/14",
      "name": "Next.js",
      "version": "14.0.0"
    }
  ]
}
```

### Error Handling

**Library Not Found:**
```json
{
  "error": "Library 'unknown-lib' not found",
  "suggestions": ["similar-lib-1", "similar-lib-2"]
}
```

**Ambiguous Results:**
```json
{
  "warning": "Multiple matches found",
  "libraries": [...],
  "hint": "Specify version or use full path"
}
```

---

## 2. `query-docs`

Retrieves documentation for a specific library using its Context7-compatible ID.

### Purpose

Fetch up-to-date, version-specific documentation and code examples for a given library.

### Parameters

| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| `libraryId` | string | Yes | Context7-compatible library ID (from `resolve-library-id`) |
| `query` | string | Yes | The user's specific question or topic |

### Returns

```json
{
  "documentation": "Markdown-formatted documentation",
  "codeExamples": [
    {
      "language": "typescript",
      "code": "...",
      "description": "..."
    }
  ],
  "version": "14.0.0",
  "source": "https://nextjs.org/docs/...",
  "lastUpdated": "2026-01-10"
}
```

### Examples

#### Example 1: Next.js Middleware

**Input:**
```json
{
  "libraryId": "/vercel/next.js/14",
  "query": "How to create middleware for authentication?"
}
```

**Output:**
```json
{
  "documentation": "# Next.js Middleware\n\nMiddleware allows you to run code before a request is completed...",
  "codeExamples": [
    {
      "language": "typescript",
      "code": "import { NextResponse } from 'next/server'\nimport type { NextRequest } from 'next/server'\n\nexport function middleware(request: NextRequest) {\n  // Your authentication logic\n}",
      "description": "Basic middleware setup"
    }
  ],
  "version": "14.0.0",
  "source": "https://nextjs.org/docs/app/building-your-application/routing/middleware"
}
```

#### Example 2: Supabase Authentication

**Input:**
```json
{
  "libraryId": "/supabase/supabase",
  "query": "Sign up users with email and password"
}
```

**Output:**
```json
{
  "documentation": "# Supabase Auth - Email/Password\n\nSign up new users using email and password...",
  "codeExamples": [
    {
      "language": "typescript",
      "code": "const { data, error } = await supabase.auth.signUp({\n  email: 'user@example.com',\n  password: 'secure-password'\n})",
      "description": "Sign up with email/password"
    }
  ]
}
```

#### Example 3: React Hooks

**Input:**
```json
{
  "libraryId": "/facebook/react/18",
  "query": "How to use useState hook?"
}
```

**Output:**
```json
{
  "documentation": "# useState Hook\n\nuseState is a React Hook that lets you add state to function components...",
  "codeExamples": [
    {
      "language": "jsx",
      "code": "import { useState } from 'react';\n\nfunction Counter() {\n  const [count, setCount] = useState(0);\n  \n  return (\n    <button onClick={() => setCount(count + 1)}>\n      Count: {count}\n    </button>\n  );\n}",
      "description": "Basic useState example"
    }
  ],
  "version": "18.2.0"
}
```

### Error Handling

**Invalid Library ID:**
```json
{
  "error": "Invalid library ID format",
  "expected": "/org/project or /org/project/version",
  "received": "invalid-id"
}
```

**Library Not Found:**
```json
{
  "error": "Library '/unknown/lib' not found",
  "suggestions": ["/similar/lib1", "/similar/lib2"]
}
```

**No Documentation Found:**
```json
{
  "error": "No documentation found for query",
  "query": "your-query",
  "suggestion": "Try rephrasing or check library version"
}
```

---

## 📊 Response Structure

### Documentation Object

```typescript
interface DocumentationResponse {
  documentation: string;          // Markdown content
  codeExamples: CodeExample[];    // Array of code snippets
  version: string;                // Library version
  source: string;                 // Source URL
  lastUpdated: string;            // ISO 8601 date
  relatedTopics?: string[];       // Related documentation
}
```

### Code Example Object

```typescript
interface CodeExample {
  language: string;      // Programming language
  code: string;          // Code snippet
  description: string;   // What the code does
  filename?: string;     // Suggested filename
  runnable?: boolean;    // Can be executed as-is
}
```

### Library Object

```typescript
interface Library {
  id: string;           // Context7 ID (/org/project)
  name: string;         // Display name
  description?: string; // Brief description
  version: string;      // Version number
  stars?: number;       // GitHub stars
  deprecated?: boolean; // Deprecation status
}
```

---

## 🔍 Library ID Format

### Standard Format

```
/organization/project
```

**Examples:**
- `/vercel/next.js`
- `/supabase/supabase`
- `/facebook/react`

### With Version

```
/organization/project/version
```

**Examples:**
- `/vercel/next.js/14`
- `/facebook/react/18.2.0`
- `/supabase/supabase/2.0`

### Version Formats

- Exact: `/vercel/next.js/14.0.3`
- Major: `/vercel/next.js/14`
- Latest: `/vercel/next.js` (default)

---

## 🎯 Common Patterns

### Pattern 1: Two-Step Query

**Recommended workflow:**

```typescript
// Step 1: Resolve library name
const libraryResult = await resolveLibraryId({
  query: "Create authentication",
  libraryName: "supabase"
});

const libraryId = libraryResult.libraries[0].id;

// Step 2: Query documentation
const docs = await queryDocs({
  libraryId: libraryId,
  query: "Create authentication"
});
```

### Pattern 2: Direct Query (With Known ID)

**When you know the exact library ID:**

```typescript
const docs = await queryDocs({
  libraryId: "/supabase/supabase",
  query: "Real-time subscriptions"
});
```

### Pattern 3: Version-Specific Query

**Specify exact version:**

```typescript
const docs = await queryDocs({
  libraryId: "/vercel/next.js/14.0.0",
  query: "Server actions"
});
```

---

## ⚡ Performance Tips

### 1. Cache Library IDs

Don't resolve the same library repeatedly:

```typescript
// Bad: Resolve every time
const id = await resolveLibraryId({ libraryName: "react", query: "..." });

// Good: Cache the ID
const REACT_ID = "/facebook/react/18";
const docs = await queryDocs({ libraryId: REACT_ID, query: "..." });
```

### 2. Batch Similar Queries

Group related documentation requests:

```typescript
// Multiple queries for same library
const queries = [
  "useState hook",
  "useEffect hook",
  "useContext hook"
];

for (const query of queries) {
  await queryDocs({ libraryId: REACT_ID, query });
}
```

### 3. Use Specific Versions

More specific = faster + more accurate:

```typescript
// Slower: Latest version lookup
libraryId: "/vercel/next.js"

// Faster: Exact version
libraryId: "/vercel/next.js/14.0.3"
```

---

## 📈 Rate Limits

### Without API Key

- **Requests**: 60 per hour
- **Reset**: Every hour
- **Recommended**: For testing only

### With Free API Key

- **Requests**: 1,000 per month
- **Burst**: 100 per minute
- **Reset**: Monthly
- **Recommended**: Personal projects

### With Paid API Key

- **Requests**: Custom limits
- **Burst**: Custom limits
- **Support**: Priority
- **Recommended**: Production use

### Rate Limit Headers

Response includes:
```
X-RateLimit-Limit: 1000
X-RateLimit-Remaining: 750
X-RateLimit-Reset: 1704124800
```

---

## 🔒 Authentication

### API Key Header

```http
CONTEXT7_API_KEY: ctx7_your_key_here
```

### OAuth Token

```http
Authorization: Bearer oauth_token_here
```

---

## 🐛 Error Codes

| Code | Meaning | Solution |
|------|---------|----------|
| 400 | Bad Request | Check parameters |
| 401 | Unauthorized | Add/check API key |
| 403 | Forbidden | Check API key permissions |
| 404 | Not Found | Verify library ID exists |
| 429 | Rate Limit | Wait or upgrade plan |
| 500 | Server Error | Retry or report issue |

---

**Next Steps**: See `examples.md` for practical usage examples
