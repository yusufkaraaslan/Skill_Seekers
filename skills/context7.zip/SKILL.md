---
name: context7
description: Context7 MCP server documentation - Use this skill when working with Context7, implementing real-time library documentation features, understanding MCP protocol integration, setting up AI coding assistants with up-to-date documentation, or solving LLM outdated training data problems.
---

# Context7 MCP Server - Up-to-Date Documentation for AI Coding Assistants

Complete guide to Context7, the Model Context Protocol (MCP) server that delivers real-time, version-specific library documentation to LLMs and AI code editors.

## 🎯 What is Context7?

Context7 is an **MCP (Model Context Protocol) server** developed by Upstash that solves the critical problem of outdated documentation in AI coding assistants.

### Problems Solved

**❌ Without Context7:**
- Code examples based on year-old training data
- Hallucinated APIs that don't exist
- Generic answers for old package versions
- Wrong syntax for current library versions
- Outdated best practices

**✅ With Context7:**
- ✨ Up-to-date, version-specific documentation
- ✨ Real code examples from official sources
- ✨ Accurate API references
- ✨ Latest library syntax and patterns
- ✨ Current best practices

### How It Works

1. **You ask**: "Create Next.js middleware to validate JWT. use context7"
2. **Context7**: Fetches latest Next.js 15 documentation
3. **LLM receives**: Current, accurate docs in context
4. **You get**: Working code with correct APIs

---

## 🚀 Quick Start

### Prerequisites

- **Supported Clients**: Cursor, Claude Code, Opencode, or any MCP-compatible editor
- **API Key**: Get free key at [context7.com/dashboard](https://context7.com/dashboard) (optional but recommended for higher rate limits)

### Installation

#### Option 1: Cursor (Remote Server) ⭐ Recommended

Add to `~/.cursor/mcp.json`:

```json
{
  "mcpServers": {
    "context7": {
      "url": "https://mcp.context7.com/mcp",
      "headers": {
        "CONTEXT7_API_KEY": "YOUR_API_KEY"
      }
    }
  }
}
```

#### Option 2: Cursor (Local Server)

Add to `~/.cursor/mcp.json`:

```json
{
  "mcpServers": {
    "context7": {
      "command": "npx",
      "args": [
        "-y",
        "@upstash/context7-mcp",
        "--api-key",
        "YOUR_API_KEY"
      ]
    }
  }
}
```

#### Option 3: Claude Code

```bash
claude mcp add context7 -- npx -y @upstash/context7-mcp --api-key YOUR_API_KEY
```

#### Option 4: Other MCP Clients

Use NPX command:
```bash
npx -y @upstash/context7-mcp --api-key YOUR_API_KEY
```

### OAuth Support

For clients supporting MCP OAuth specification, change endpoint:
- From: `https://mcp.context7.com/mcp`
- To: `https://mcp.context7.com/mcp/oauth`

---

## 📖 Usage Guide

### Basic Usage

Simply add "use context7" to your prompts:

```
Create a React component for user authentication. use context7
```

```
How do I set up Next.js 14 middleware? use context7
```

### Specify Library

Use the slash syntax `/org/project`:

```
use library /supabase/supabase for API and docs
```

```
use library /vercel/next.js to create API routes
```

### Specify Version

Mention version in your prompt:

```
Create Next.js 15 server actions. use context7
```

```
How to use React 18 concurrent features? use context7
```

### Automatic Invocation

**Best Practice**: Set up rules to automatically invoke Context7

**In Cursor:**
1. Go to Settings → Rules
2. Add rule:
   ```
   For all code-related tasks, use context7 to fetch latest documentation
   ```

**Benefits:**
- No need to type "use context7" every time
- Consistent up-to-date documentation
- Better code quality

---

## 🛠️ Available Tools

Context7 provides 2 main MCP tools:

### 1. `resolve-library-id`

**Purpose**: Convert library names to Context7-compatible IDs

**Parameters**:
- `query` (string): User's question or request
- `libraryName` (string): Name of the library

**Example**:
```
Input: query="How to authenticate?", libraryName="supabase"
Output: /supabase/supabase
```

**When to use**:
- MUST call before `query-docs` UNLESS user provides explicit ID format `/org/project`

### 2. `query-docs`

**Purpose**: Retrieve documentation using library IDs

**Parameters**:
- `libraryId` (string): Context7-compatible ID (from `resolve-library-id`)
- `query` (string): User's question or request

**Example**:
```
Input: libraryId="/vercel/next.js", query="Create middleware"
Output: Latest Next.js middleware documentation
```

---

## 💡 Advanced Features

### Version Detection

Context7 automatically detects versions from your prompt:

```
"Next.js 14" → Fetches Next.js 14 docs
"React 18" → Fetches React 18 docs
"Python 3.12" → Fetches Python 3.12 docs
```

### Multi-Library Support

Combine multiple libraries in one prompt:

```
Create a Next.js app with Supabase auth and Tailwind styling. use context7
```

Context7 will fetch docs for all mentioned libraries.

### Custom Library Paths

Use full paths for precise control:

```
use library /facebook/react/18.2.0
```

---

## 🎯 Use Cases

### 1. Web Development

```
Create Next.js 15 server actions for form handling. use context7
```

### 2. Database Integration

```
use library /supabase/supabase
Show me how to set up real-time subscriptions
```

### 3. UI Frameworks

```
Create a Tailwind CSS responsive navbar with dark mode. use context7
```

### 4. Backend Development

```
use library /fastify/fastify
Create REST API with JWT authentication
```

### 5. Cloud Services

```
use library /aws/aws-sdk-js-v3
How to upload files to S3?
```

---

## 🔧 Configuration

### API Key (Recommended)

**Why use an API key?**
- 🚀 Higher rate limits
- 🔒 Authenticated access
- 📊 Usage tracking
- 💰 Free tier available

**Get API Key:**
1. Visit [context7.com/dashboard](https://context7.com/dashboard)
2. Sign up (free)
3. Copy your API key
4. Add to configuration (see Installation section)

### Without API Key

Context7 works without an API key but with:
- ⚠️ Lower rate limits
- ⚠️ Slower response times
- ⚠️ No usage analytics

---

## 📊 Supported Clients

Context7 works with 30+ MCP-compatible clients:

### Officially Supported

- ✅ **Cursor** (Most popular)
- ✅ **Claude Code** (Anthropic)
- ✅ **Opencode**
- ✅ **Windsurf**
- ✅ **Aide**
- ✅ **Goose**

### Configuration Methods

| Client | Method | Difficulty |
|--------|--------|------------|
| Cursor | Remote or Local | ⭐ Easy |
| Claude Code | CLI command | ⭐ Easy |
| Opencode | NPX command | ⭐⭐ Medium |
| Others | MCP JSON config | ⭐⭐ Medium |

---

## 🌟 Best Practices

### 1. Always Specify Versions

❌ **Bad**:
```
How to use React hooks?
```

✅ **Good**:
```
How to use React 18 hooks? use context7
```

### 2. Use Library Paths

❌ **Bad**:
```
How to use Supabase?
```

✅ **Good**:
```
use library /supabase/supabase
How to implement authentication?
```

### 3. Set Up Automation

❌ **Manual**:
```
Every prompt: "use context7"
```

✅ **Automated**:
```
Set Cursor rule: Always use context7 for code
```

### 4. Combine with Specific Queries

❌ **Vague**:
```
Help with Next.js
```

✅ **Specific**:
```
Create Next.js 15 API route with error handling. use context7
```

---

## 🔍 Troubleshooting

### Context7 Not Working

**Check:**
1. ✅ MCP server is running (check Cursor/Claude logs)
2. ✅ API key is valid (if using one)
3. ✅ Correct endpoint URL
4. ✅ "use context7" in prompt

**Restart:**
```bash
# Cursor: Restart MCP servers
Cmd/Ctrl + Shift + P → "MCP: Restart Servers"

# Claude Code:
claude mcp restart
```

### Rate Limit Errors

**Solution:**
- Get API key at context7.com/dashboard
- Use local server instead of remote
- Reduce request frequency

### Library Not Found

**Check:**
- Library name spelling
- Use slash syntax: `/org/project`
- Try `resolve-library-id` first

**Example:**
```
# Wrong
use library supabase

# Right
use library /supabase/supabase
```

### Outdated Documentation

**Verify:**
- Check version mentioned in prompt
- Use explicit version: `/org/project/version`
- Clear cache and retry

---

## 📚 Resources

### Official Links

- **Website**: https://context7.com
- **Dashboard**: https://context7.com/dashboard
- **GitHub**: https://github.com/upstash/context7
- **NPM Package**: [@upstash/context7-mcp](https://www.npmjs.com/package/@upstash/context7-mcp)
- **Blog**: https://upstash.com/blog/context7-mcp

### Documentation

- **Setup Guides**: See `references/setup.md`
- **API Reference**: See `references/api.md`
- **Examples**: See `references/examples.md`
- **Client Configs**: See `references/clients.md`

### Community

- **GitHub Issues**: Report bugs or request features
- **Upstash Discord**: Community support
- **Blog Posts**: Usage guides and tutorials

---

## 📈 Repository Stats

- **⭐ Stars**: 41,500+ (highly popular)
- **🍴 Forks**: 2,000+
- **📝 Commits**: 633+
- **📜 License**: MIT
- **🏢 Organization**: Upstash
- **📅 Created**: March 26, 2025

---

## 🔐 Security & Privacy

### Data Handling

- 🔒 API keys stored securely
- 🔒 No code sent to Context7 servers
- 🔒 Only documentation queries processed
- 🔒 OAuth support for enhanced security

### Best Practices

1. **Store API keys securely**
   - Use environment variables
   - Don't commit to version control
   - Rotate keys regularly

2. **Use OAuth when available**
   - More secure than API keys
   - Token-based authentication
   - Granular permissions

3. **Local vs Remote**
   - Local: Better privacy, runs on your machine
   - Remote: Better performance, managed infrastructure

---

## 🚀 What's Next?

### After Setup

1. ✅ Test with simple query
2. ✅ Set up automation rules
3. ✅ Explore different libraries
4. ✅ Integrate into workflow

### Advanced Usage

- Create custom library collections
- Build MCP client integrations
- Contribute to Context7 repository
- Share usage patterns with community

---

**Last Updated**: January 2026
**Version**: Latest
**Maintained by**: Upstash Team
